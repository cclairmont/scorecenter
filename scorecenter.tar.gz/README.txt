To my knowledge all requirements have been implemented correctly

I have not collaborated with anyone

This took approximately 4 hours to complete.
