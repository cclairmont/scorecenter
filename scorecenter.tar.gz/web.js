var express = require('express');
var mongodb = require('mongodb');
var mongoUri = 'mongodb://scorecenter:scorecenter@alex.mongohq.com:10020/app14829775/scorecenter'
var db = mongodb.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});

var app = express(express.logger());
app.use(express.bodyParser());

app.post('/submit.json',function (req,res) {
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Content-Type', 'application/json');
    db.collection('scores',function(err,collection){
        var new_score = req.body;
        new_score.score = parseInt(new_score.score);
        new_score.created_at = new Date().toDateString();
        collection.insert(new_score)
    });
    res.send(200);
});

app.get('/highscores.json',function(req,res) {
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Content-Type', 'application/json');
    if (req.query.game_title) {
        db.collection('scores',function(err,collection){
            var cursor = collection.find({game_title: req.query.game_title});
            cursor.sort({score: -1});
            cursor.limit(10);
            cursor.toArray(function(err,scores){
                res.send(JSON.stringify(scores));
	        });
	});
    }
    else
        res.send(400);
});

app.get('/',function(req,res) {
    var ret_str = '<h1>ScoreCenter</h1><ol>';
    db.collection('scores',function(err,collection){
        var cursor = collection.find();
        cursor.sort({game_title: 1,score: -1});
        var curr_title = null;
        cursor.each(function(err,item){
            if(item) {
                if(curr_title != item.game_title) {
                    curr_title = item.game_title;
                    ret_str += '</ol><h2>' + curr_title + '</h2><ol>';
	        }
                ret_str += '<li>' + item.username + ': ' + item.score + 
                           ' on ' + item.created_at + '</li>';
	    } else res.send(ret_str);
	});
    });
});

app.get('/username',function (req,res) {
    if (req.query.user) {
        var ret_str = '<h1>' + req.query.user + '</h1><ol>';
        db.collection('scores',function(err,collection){
            var cursor = collection.find({username: req.query.user});
            cursor.sort({game_title: 1,score: -1});
            var curr_title = null;
            cursor.each(function(err,item){
                if(item) {
                    if(curr_title != item.game_title) {
                        curr_title = item.game_title;
                        ret_str += '</ol><h2>' + curr_title + '</h2><ol>';
	            }
                    ret_str += '<li>' + item.score + 
                               ' on ' + item.created_at + '</li>';
	        } else res.send(ret_str);
	    });
	});
    }
    else res.send('<form action="username" method="get">' +
                  'Username: <input type="text" name="user">' +
                  '<input type="submit" value="Submit"></form>');
});

app.get('/*',function (req,res) {
    res.send("Hello");
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});